---------------------------------------------------------------------------------------
-- Simul Play
-- TA-PRE-1
--
-- Silicon Valley Code Camp 2014 Presentation
--
-- Copyright Tinker Academy 2014
---------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------
-- Questions about our Beginner or AP Level Computer Science classes?
-- Email us at classes@tinkeracademy.com
---------------------------------------------------------------------------------------

widget = require("widget")

scoreButton = widget.newButton
{
	id = "score",
	isEnabled = false,
	fontSize = 48,
	font = "Arial",
	x = 48,
	y = 48,
	textOnly = true,
	labelColor = { default={ 1, 1, 0 } }
}

function displayScore(score)
	scoreButton:setLabel(score)
end

displayScore(0)

startButton = widget.newButton
{
	id = "start",
	label = "START",
	fontSize = 48,
	font = "Arial",
	x = 160,
	y = 240,
	labelColor = { default={ 0, 1, 0 }, over={0, 1, 0} }
}


-- Add your code below this
















