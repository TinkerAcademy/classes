/**
 * 
 */

/**
 * @author student
 *
 */
public class Homework1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO (Add your code below)
	
	}

}
