/**
 * Homework2.java 
 * 
 * Code to be used as part of Homework2 of
 * 
 * TA-JAV-1 Programming Using Java
 * 
 * Copyright TinkerAcademy 2014
 */

/** 
 * 
 * @author student
 *
 */
public class MyExample {

	/**
	 * Add a public static method called printClassName below.
	 * The method should not accept any input.
	 * The method should print the text "MyExample" on the Console.
	 */
	
	
}
