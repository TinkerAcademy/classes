/**
 * MyMinecraftPlayerInfo.java
 * 
 * Copyright Tinker Academy 2014
 * 
 */

/**
 * @author student
 *
 */
public class MyMinecraftPlayerInfo {
		
}
