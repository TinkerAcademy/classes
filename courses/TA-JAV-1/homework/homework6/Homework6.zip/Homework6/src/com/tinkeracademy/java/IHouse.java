package com.tinkeracademy.java;

public interface IHouse {

	public void build();
}
