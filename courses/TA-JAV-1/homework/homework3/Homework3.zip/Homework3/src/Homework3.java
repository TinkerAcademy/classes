/**
 * Homework3.java
 * 
 * Homework 3 of Programming in Java
 * 
 * This homework is graded. 
 * 
 * Refer to instructions on the last page of the Handout3 to complete this homework. 
 * 
 * Copyright Tinker Academy 2014
 */

/**
 * The Homework3 class.
 * 
 * @author student
 *
 */
public class Homework3 {

	/**
	 * This is the first method that will be executed by the Java Virtual Machine.
	 * 
	 * It accepts some input and then prints some text to the console.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Homework 3");
		
		//TODO (2)
	}

}
