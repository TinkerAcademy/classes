/**
 * Example1.java
 * 
 * Example program showing the use of the 
 * 	keyword static in method signatures
 * 	keyword void in method signatures
 */

/**
 * @author student
 *
 */
public class Example1 {

	
	/**
	 * This is an example of a static method
	 * 
	 * The method can be invoked using the code
	 * 
	 * Example1.staticMethod1()
	 */
	public static void staticMethod1() {
		System.out.println("Example1.staticMethod1 invoked successfully.");
	}
	
}
