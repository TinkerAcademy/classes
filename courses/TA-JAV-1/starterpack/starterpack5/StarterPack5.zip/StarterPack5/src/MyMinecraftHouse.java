

/**
 * MyMinecraftHouse.java
 * 
 * Copyright Tinker Academy 2014
 * 
 */

/**
 * @author student
 *
 */
public class MyMinecraftHouse {
	
	public MyMinecraftHouse(String name, int width, int height) { 
		this.name = name; 
		this.width = width;
		this.height = height;
	} 
	
	private int width;
	
	private int height;
	
	private String name;
	
	/**
	 * Builds a House
	 */
	public void build() {
		
	}


	public int getWidth() {
		return width;
	}


	public int getHeight() {
		return height;
	}


	public String getName() {
		return name;
	}

}
