/**
 * StarterPack3.java
 * 
 * Your First Java Program
 */

/**
 * The StarterPack3 class will be used to understand the structure of a Java program.
 * 
 * @author student
 *
 */
public class StarterPack3 {

	/**
	 * This is the first method that will be executed by the Java Virtual Machine.
	 * 
	 * It accepts some input and then prints some text to the console.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Starter Pack 3");
		//TODO (4)
		//TODO (5)
		//TODO (6)
	}

}
