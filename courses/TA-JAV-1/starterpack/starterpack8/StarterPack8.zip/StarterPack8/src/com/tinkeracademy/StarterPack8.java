package com.tinkeracademy;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * StarterPack8.java
 */

/**
 * The StarterPack8 class will be used to understand the structure of a Java program.
 * 
 * Copyright Tinker Academy 2014
 * 
 * @author student
 *
 */
public class StarterPack8 extends JavaPlugin{

	/**
	 * This is the first method that will be executed by the Java Virtual Machine.
	 * 
	 * It accepts some input and then prints some text to the console.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Starter Pack 8");
	}

	@Override
	public boolean onCommand(CommandSender sender, Command command,
			String label, String[] args) {
		return false;
	}

	private int extractInt(String[] args, int index, int defaultValue) {
		if (args.length > index ) {
			return Integer.valueOf(args[index]);
		}
		return defaultValue;
	}



}
