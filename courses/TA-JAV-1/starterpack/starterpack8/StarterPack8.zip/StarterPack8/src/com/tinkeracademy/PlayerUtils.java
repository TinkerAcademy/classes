package com.tinkeracademy;

import org.bukkit.Location;
import org.bukkit.entity.Player;

public class PlayerUtils {

	public static String buildPlayerInfoMessage(Player player) {
        String msg = " Your list name is " + player.getPlayerListName();
        msg += "\n";
        msg += "Your experience is " + player.getExp();
        msg += "\n";
        msg += "Your food is at " + player.getFoodLevel();
        msg += "\n";
        if (player.isOnGround()) {
        	msg += "You are on the ground.";
        } else {
        	msg += "You are off the ground.";
        }
		return msg;
	}
	
	public static void teleportPlayer(Player player, Location newLocation) {
		player.teleport(newLocation);
	}
}
