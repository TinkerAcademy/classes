package com.tinkeracademy;

/**
 * Interface that describes the set of methods for a house.
 * 
 * This interface indicates that every house has a build method.
 * 
 * @author student
 *
 */
public interface IHouse {

	public void build();
}
