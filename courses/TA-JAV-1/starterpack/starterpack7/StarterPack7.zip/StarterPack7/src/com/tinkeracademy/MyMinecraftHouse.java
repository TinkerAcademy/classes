package com.tinkeracademy;


import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;

/**
 * MyMinecraftHouse.java
 * 
 * Copyright Tinker Academy 2014
 * 
 */

/**
 * Base class of all Minecraft Houses
 * 
 * This class is abstract which means the class blueprint is incomplete.
 * This class has a an abstract method build.
 * 
 * Subclasses would need to extend this class and define the build method.
 * 
 * @author student
 */
public abstract class MyMinecraftHouse implements IHouse {
	
	/**
	 * Special byte value to indicate the top of the door.
	 * 
	 * The number starts with 0x and therefore it is in hexadecimal.
	 * 
	 */
	private static byte TOP_OF_DOOR = 0x8;
	
	/**
	 * Special byte value to indicate the bottom of the door. 
	 * 
	 * The number starts with 0x and therefore it is in hexadecimal.
	 * 
	 */
	public static byte BOTTOM_OF_DOOR = 0x0;
	
	/**
	 * Special byte value to indicate the door is open.
	 * 
	 * The number starts with 0x and therefore it is in hexadecimal.
	 * 
	 */
	public static byte DOOR_IS_OPEN = 0x4;
	
	/**
	 * Special byte value to indicate the door is closed.
	 * 
	 * The number starts with 0x and therefore it is in hexadecimal.
	 * 
	 */
	public static byte DOOR_IS_CLOSED = 0x0;
	
	/**
	 * Special byte value to indicate the door faces east.
	 * 
	 * The number starts with 0x and therefore it is in hexadecimal.
	 * 
	 */
	public static byte DOOR_FACING_EAST = 0x0;
	
	/**
	 * Special byte value to indicate the door faces north.
	 * 
	 * The number starts with 0x and therefore it is in hexadecimal.
	 * 
	 */
	public static byte DOOR_FACING_NORTH = 0x1;
	
	/**
	 * Special byte value to indicate the door faces west.
	 * 
	 * The number starts with 0x and therefore it is in hexadecimal.
	 * 
	 */
	public static byte DOOR_FACING_WEST = 0x2;
	
	/**
	 * Special byte value to indicate the door faces south.
	 * 
	 * The number starts with 0x and therefore it is in hexadecimal.
	 * 
	 */
	public static byte DOOR_FACING_SOUTH = 0x3;
	
	
	
	/**
	 * The outside width of the house.
	 * 
	 */
	protected int width;
	
	/**
	 * The outside height of the house.
	 * 
	 */
	protected int height;
	
	/**
	 * The name of the house.
	 * 
	 */
	protected String name;
	
	/**
	 * The center of the house.
	 * 
	 */
	protected Location center;
		
	/**
	 * The constructor for the house.
	 * 
	 * @param name
	 * @param width
	 * @param height
	 * @param location
	 */
	public MyMinecraftHouse(String name, int width, int height, Location location) { 
		this.name = name; 
		this.width = width;
		this.height = height;
		this.center = location;
	} 
	
	public int getWidth() {
		return width;
	}


	public int getHeight() {
		return height;
	}


	public String getName() {
		return name;
	}
	
	public Location getCenter() {
		return center;
	}
	
	/**
	 * Builds a House
	 * 
	 * Subclasses need to override this method to build the actual house
	 */
	public abstract void build();
	
	/**
	 * Builds the basic structure of a house.
	 * 
	 * The outside of the house is made of "outsideMaterial".
	 * The inside of the house is made of Material.AIR
	 * 
	 * The walls of the house are 1 block thick. 
	 * 
	 * @param center
	 * @param width
	 * @param height
	 * @param outsideMaterial
	 */
	protected void buildStructure(Material outsideMaterial) {
		Location outside = createLocationAtOffset(center, -width/2, -1, -width/2);
		makeCube(outside, width, height, outsideMaterial);
		Location inside = createLocationAtOffset(outside, 1, 1, 1);
		makeCube(inside, width - 2, height - 2, Material.AIR);		
	}
	
	/**
	 * Adds a door. The material of the door is "doorMaterial".
	 * 
	 * Doors in Minecraft are 2 blocks high.
	 * 
	 * The top block has a special byte value TOP_OF_DOOR (0x8) that indicates that its the top of the door.
	 * 
	 * @param bottomOfDoor
	 * @param doorMaterial
	 * @return
	 */
	protected Location addDoor(Location wall, Material doorMaterial, byte facing, byte open) {
		// The code below configures the bottom half of the door
		Location bottomOfDoor = createLocationAtOffset(wall, 0, 0, 0);
		Block block = bottomOfDoor.getBlock();
		block.setType(doorMaterial);
		byte data = BOTTOM_OF_DOOR;
		data += facing;
		data += open;
		block.setData(data);
		// The code below configures the top half of the door
		Location topOfDoor = createLocationAtOffset(bottomOfDoor, 0, 1, 0);
		// The code below configures the top block of the door
		block = topOfDoor.getBlock();
		block.setType(doorMaterial);	
		data = TOP_OF_DOOR;
		block.setData(data);
		return topOfDoor;
	}

	/**
	 * Adds a torch. The material of the torch is "torchMaterial".
	 * 
	 * @param wall
	 * @param torchMaterial
	 */
	protected void addTorch(Location wall, Material torchMaterial) {
		Location torchLocation = createLocationAtOffset(wall, 0, 3, 0);
		Block torchBlock = torchLocation.getBlock();
		torchBlock.setType(torchMaterial);		
	}
	
	/**
	 * Useful helper method to make a cube using the "material" as the material.
	 * 
	 * The method sets all the blocks in the cube to the material "material"
	 * 
	 * Cubes in minecraft are oriented in the X, Y and Z direction.
	 * 
	 * The X direction indicates the width of the cube.
	 * The Y direction indicates the height of the cube.
	 * The Z direction indicates the depth of the cube.
	 * 
	 * @param loc
	 * @param width
	 * @param height
	 * @param material
	 */
	protected void makeCube(Location loc, int width, int height, Material material) {
		Location blockLoc;
		// The outer for loop handles the blocks in the X direction
		// The inner for loop handles the blocks in the Z direction
		// The middle for loop handles the blocks in the Y direction
		int i;
		int j;
		int k;
		for (i = 0; i < width; ++i) {
			for (j = 0; j < height; ++j) {
				for (k = 0; k < width; ++k) {
					blockLoc = createLocationAtOffset(loc, i, j, k);
			        Block block = blockLoc.getBlock();
			        block.setType(material);
				}
			}
		}
	}
	
	/**
	 * Useful helpful method to create a new location offset from some location.
	 * 
	 * @param loc
	 * @param offsetX
	 * @param offsetY
	 * @param offsetZ
	 * @return
	 */
	protected Location createLocationAtOffset(Location loc, double offsetX, double offsetY, double offsetZ) {
		Location newLoc = new Location(loc.getWorld(), 0, 0, 0);
		newLoc.setX(loc.getX() + offsetX);
		newLoc.setY(loc.getY() + offsetY);
		newLoc.setZ(loc.getZ() + offsetZ);
		return newLoc;
	}

	/**
	 * Useful helper method to locate the north wall of the house.
	 * 
	 * @param inside if true returns the inside part of the wall
	 * 				 if false returns the outside part of the wall
	 * @return
	 */
	protected Location getLocationOfNorthWall(boolean inside) {
		Location wall = null;
		if (inside) {
			wall = createLocationAtOffset(center, 0, 0, width/2 - 2);
		} else {
			wall = createLocationAtOffset(center, 0, 0, width/2 - 1);
		}
		return wall;
	}
	
	/**
	 * Useful helper method to locate the south wall of the house.
	 * 
	 * @param inside if true returns the inside part of the wall
	 * 				 if false returns the outside part of the wall
	 * @return
	 */
	protected Location getLocationOfSouthWall(boolean inside) {
		Location wall = null;
		if (inside) {
			wall = createLocationAtOffset(center, 0, 0, -width/2 + 1);
		} else {
			wall = createLocationAtOffset(center, 0, 0, -width/2);
		}
		return wall;
	}
	
	/**
	 * Useful helper method to locate the east wall of the house.
	 * 
	 * @param inside if true returns the inside part of the wall
	 * 				 if false returns the outside part of the wall
	 * @return
	 */
	protected Location getLocationOfEastWall(boolean inside) {
		Location wall = null;
		if (inside) {
			wall = createLocationAtOffset(center, width/2 - 2, 0, 0);
		} else {
			wall = createLocationAtOffset(center, width/2 - 1, 0, 0);
		}
		return wall;
	}
	
	/**
	 * Useful helper method to locate the west wall of the house.
	 * 
	 * @param inside if true returns the inside part of the wall
	 * 				 if false returns the outside part of the wall
	 * @return
	 */
	protected Location getLocationOfWestWall(boolean inside) {
		Location wall = null;
		if (inside) {
			wall = createLocationAtOffset(center, -width/2 + 1, 0, 0);
		} else {
			wall = createLocationAtOffset(center, -width/2, 0, 0);
		}
		return wall;
	}
	
}
