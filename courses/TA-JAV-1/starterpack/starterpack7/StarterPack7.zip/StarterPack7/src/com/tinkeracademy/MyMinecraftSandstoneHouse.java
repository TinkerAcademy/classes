package com.tinkeracademy;


import org.bukkit.Location;
import org.bukkit.Material;

/**
 * MyMinecraftHouse.java
 * 
 * Copyright Tinker Academy 2014
 * 
 */

/**
 * A Sandstone House in Minecraft
 * 
 * @author student
 *
 */
public class MyMinecraftSandstoneHouse extends MyMinecraftHouse {
	
	/**
	 * Constructor takes 3 inputs, the name of the house, the width of the house and the location of center.
	 * 
	 * The constructor simply invokes the superclass constructor with the 3 inputs.
	 * 
	 * @param name
	 * @param width
	 * @param height
	 * @param center
	 */
	public MyMinecraftSandstoneHouse(String name, int width, int height, Location center) { 
		super(name, width, height, center);
	} 
	
	/** 
	 * Builds the house.
	 * 
	 * First the basic structure of the house is created.
	 * Then doors are added
	 * Torches are added inside the house on all the four walls
	 * 
	 */
	public void build() {
	}
	
	/**
	 * Adds doors to outside of all 4 walls.
	 * 
	 * The door material is Material.WOOD
	 */
	private void addDoors() {
		Location northWall = getLocationOfNorthWall(false);
		addDoor(northWall, Material.WOODEN_DOOR, DOOR_FACING_NORTH, DOOR_IS_CLOSED);
		Location southWall = getLocationOfSouthWall(false);
		addDoor(southWall, Material.WOODEN_DOOR, DOOR_FACING_SOUTH, DOOR_IS_CLOSED);
		Location eastWall = getLocationOfEastWall(false);
		addDoor(eastWall, Material.WOODEN_DOOR, DOOR_FACING_EAST, DOOR_IS_CLOSED);
		Location westWall = getLocationOfWestWall(false);
		addDoor(westWall, Material.WOODEN_DOOR, DOOR_FACING_WEST, DOOR_IS_CLOSED);
	}
	
	/**
	 * Adds torches to inside of all 4 walls.
	 * 
	 * The torch material is Material.TORCH
	 */
	private void addTorches() {
		Location northWall = getLocationOfNorthWall(true);
		addTorch(northWall, Material.TORCH);
		Location southWall = getLocationOfSouthWall(true);
		addTorch(southWall, Material.TORCH);
		Location eastWall = getLocationOfEastWall(true);
		addTorch(eastWall, Material.TORCH);
		Location westWall = getLocationOfWestWall(true);
		addTorch(westWall, Material.TORCH);
	}
	
}
