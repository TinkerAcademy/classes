/**
 * MyMinecraftHouse.java
 * 
 * Copyright Tinker Academy 2014
 * 
 */

/**
 * @author student
 *
 */
public class MyMinecraftHouse {
	
	//TODO (6)
	
	
	

	//TODO (2)
	
	
	
	//TODO (1)
	
	
	
	//TODO (5)
	
	
	//TODO (7)
	
}
