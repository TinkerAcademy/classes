
public class InsertionSort {

	public void sort(int[] input, int m, int n) {
		for (int i = 1; i < input.length;i++) {
			int j = i;
			while (j > 0 && input[j-1] > input[j]) {
				int tmp = input[j];
				input[j] = input[j-1];
				input[j-1] = tmp;
				j = j - 1;
           } 
		}
	}
	
}
