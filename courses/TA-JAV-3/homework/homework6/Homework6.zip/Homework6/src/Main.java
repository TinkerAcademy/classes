import java.util.Arrays;


public class Main {

	public static void main(String[] args) {
		int[] arr = { 5, 1, 4, 3, 2 };
		InsertionSort sorter = new InsertionSort();
		System.out.println(Arrays.toString(arr));
		sorter.sort(arr, 2, 4);
		System.out.println(Arrays.toString(arr));	
	}

}
