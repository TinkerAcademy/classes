package com.tinkeracademy.sort;

public class Main {

	public static void main(String[] args) {	
		BubbleSort bubbleSort = new BubbleSort();
		int[] input = { 5, 2, 4, 1, 3 };
		bubbleSort.sort(input);
	}
	
}
