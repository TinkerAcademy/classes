import java.util.Arrays;


public class Main {

	public static void main(String[] args) {
		int[] arr = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		System.out.println("arr="+Arrays.toString(arr));
		sumArray(arr);
		System.out.println("sum of elements in arr="+Arrays.toString(arr));
		reverseArray(arr);
		System.out.println("reversed arr="+Arrays.toString(arr));
	}
	
	public static int sumArray(int[] arr) {
		int result = 0;
		// Write your code below
		// Assign the value of the sum of the array elements to result
		
		
		return result;
	}
	
	public static void reverseArray(int[] arr) {
		// Write your code below
		
	}

}
