
public class HelloObjects2 {

	public static void main(String[] args) {
		Car roadster = new Car();
		Car bugatti = new Car();
		
		
	}

}
