
public class Car {

	// declare data fields below this line

	// declare methods below this line

}
