package com.tinkeracademy.sort;

import java.util.Arrays;

public class BubbleSort {

	public void sort(int[] input) {
		System.out.println(Arrays.toString(input));
		// TODO Sorting Algorithm
		System.out.println(Arrays.toString(input));
	}
	
}
