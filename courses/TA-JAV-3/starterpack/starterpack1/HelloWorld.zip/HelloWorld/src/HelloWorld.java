
/**
 * HelloWorld.java
 * 
 * @author tinkeracademystudent
 *
 */
public class HelloWorld {

	/**
	 * The main method
	 * 
	 * This is the first method called by the JVM
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		// print the text "Hello World" to the console
		System.out.println("Hello World");
		
	}

}
