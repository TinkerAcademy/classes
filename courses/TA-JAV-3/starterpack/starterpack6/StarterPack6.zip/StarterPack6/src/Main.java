import java.util.Arrays;


public class Main {

	public static void main(String[] args) {
		int[] arr = { 5, 2, 1, 3, 4 };
		InsertionSort sorter = new InsertionSort();
		System.out.println(Arrays.toString(arr));
		sorter.sort(arr);
		System.out.println(Arrays.toString(arr));			
	}

}
