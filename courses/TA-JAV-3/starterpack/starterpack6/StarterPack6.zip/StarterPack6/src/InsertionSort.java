
public class InsertionSort {

	public void sort(int[] input) {
		
	}

}
