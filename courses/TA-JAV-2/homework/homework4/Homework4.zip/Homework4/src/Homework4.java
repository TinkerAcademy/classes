/**
 * 
 */

/**
 * @author tinkeracademystudent
 *
 */
public class Homework4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {		
		homeworkPart1();
		homeworkPart2();
	}
	
	private static void homeworkPart1() {
		// Complete Homework Part 1 below this line
	}
	
	private static void homeworkPart2() {
		// Complete Homework Part 2 below this line
	}

}
