package com.tinkeracademy.ap;

public class Main {

	public static void main(String[] args) {
		FizzBuzz fizzBuzz = new FizzBuzz();
		fizzBuzz.print();
	}
	
}
