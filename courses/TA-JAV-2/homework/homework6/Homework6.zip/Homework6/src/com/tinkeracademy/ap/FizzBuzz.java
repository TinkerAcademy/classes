package com.tinkeracademy.ap;

public class FizzBuzz {

	public void print() {
		
		for (int i = 1; i <= 100; i++) {
//			TODO
//			if i is a multiple of 3, print "Fizz" instead of the number
//			if i is a multiple of 5, print "Buzz" instead of the number
//			if i is a multiple of both 3 and 5, print "FizzBuzz" instead of the number
//			if i is any other number print the number itself
		}
		
	}
	
}
