package com.tinkeracademy.homework5;

public class Main {

	public static void main(String[] args) {
		LoopTheLoop loopy = new LoopTheLoop(); // 1
		loopy.loop1(); // 3
		loopy.loop2(); // 9
		loopy.loop3(); // 13
	}

}
