package com.tinkeracademy.homework5;

public class LoopTheLoop {
	
	public LoopTheLoop() {
		System.out.println("constructor"); // 12
	}

	public void loop1() {
		System.out.println("loop1"); // 13	
		loop2(); // 5
	}
	
	public void loop2() {
		System.out.println("loop2"); //11, 9
		loop3(); // 4, 7
	}
	
	public void loop3() {
		System.out.println("loop3"); // 8, 10, 14
	}
	
}
