package com.tinkeracademy.ap;

public class CarGenerator {

	public Car generateCar() {
		if (Math.random() < 0.5) {
			return new Bugatti("Red", "Gray", "RedGrayBugatti.jpg");
		} else {
			return new Tesla();
		}
	}
}
