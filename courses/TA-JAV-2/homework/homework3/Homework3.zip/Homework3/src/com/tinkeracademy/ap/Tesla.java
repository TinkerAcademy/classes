package com.tinkeracademy.ap;
/**
 * 
 */

/**
 * @author tinkeracademystudent
 *
 */
public class Tesla implements Car {

	private int speed;
	
	@Override
	public int getSpeed() {
		return this.speed;
	}
	
}
