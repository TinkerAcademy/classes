package com.tinkeracademy.ap;
/**
 * @author tinkeracademystudent
 *
 */
public class Bugatti implements Car {

	public Bugatti() {
		super();
	}
	
	public Bugatti(String color1, String color2, String imageObj) {
		// sets the value of color1 for this object
		this.color1 = color1;
		// sets the value of color2 for this object
		this.color2 = color2;
		// sets the value of imageObj for this object
		this.imageObj = imageObj;
	}

	/**
	 * Name assigned to the car
	 */
	private String name;
	
	/**
	 * First color of the 2 tone car
	 */
	private String color1;

	/**
	 * Second color of the 2 tone color car
	 */
	private String color2;

	/**
	 * Image resource
	 */
	private String imageObj;
	
	/**
	 * Speed of the car
	 */
	private int speed;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the color1
	 */
	public String getColor1() {
		return color1;
	}

	/**
	 * @return the color2
	 */
	public String getColor2() {
		return color2;
	}

	/**
	 * @return the imageObj
	 */
	public String getImageObj() {
		return imageObj;
	}

	/* (non-Javadoc)
	 * @see Car#getSpeed()
	 */
	@Override
	public int getSpeed() {
		// TODO Auto-generated method stub
		return this.speed;
	}
	
	protected void start() {
		
	}
	
	protected void stop() {
		
	}
	
}
