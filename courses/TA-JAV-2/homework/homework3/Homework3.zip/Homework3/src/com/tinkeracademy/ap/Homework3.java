package com.tinkeracademy.ap;

public class Homework3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
