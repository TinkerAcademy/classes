package com.tinkeracademy.ap;

public class BugattiVeyron extends Bugatti {

	public BugattiVeyron() {
		super();
	}

	public BugattiVeyron(String color1, String color2, String imageObj) {
		super(color1, color2, imageObj);
	}
	
}
