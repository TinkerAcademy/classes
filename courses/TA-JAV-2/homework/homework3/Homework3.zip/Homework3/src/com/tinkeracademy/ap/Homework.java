package com.tinkeracademy.ap;

/**
 * HelloPolymorphism main class
 * 
 * @author tinkeracademystudent
 *
 */
public class Homework {

	/**
	 * main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// Write your code below

	}

}
