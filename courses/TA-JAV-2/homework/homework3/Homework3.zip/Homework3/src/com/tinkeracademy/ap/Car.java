package com.tinkeracademy.ap;

/**
 * The interface Car represents some of the behavior of a Car.
 * 
 * An interface describes the behavior in terms of inputs and outputs. 
 * 
 * An interface describes what the behavior is.
 * 
 * An interface does not  describe how the behavior will be implemented.
 * 
 * @author tinkeracademystudent
 *
 */
public interface Car {

	/**
	 * Get the current speed of the car
	 * 
	 * @return speed of the car
	 */
	public int getSpeed();
}
