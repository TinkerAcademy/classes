
public class Homework2 {

	public static void main(String[] args) {
		
		
	}

}
