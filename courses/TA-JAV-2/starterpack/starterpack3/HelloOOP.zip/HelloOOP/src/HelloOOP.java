

/**
 * HelloOOP main class
 * 
 * @author tinkeracademystudent
 *
 */
public class HelloOOP {

	/**
	 * main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// Write your code below

	}

}
