/**
 * HelloOOP2 main class
 * 
 * @author tinkeracademystudent
 *
 */
public class HelloOOP2 {

	/**
	 * main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// Write your code below
	}

}
