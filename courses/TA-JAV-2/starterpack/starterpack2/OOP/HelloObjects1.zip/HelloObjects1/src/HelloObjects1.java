
public class HelloObjects1 {

	public static void main(String[] args) {

		
	}

}
